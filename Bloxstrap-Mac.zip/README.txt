Bloxstrap Mac
=============
1. Unzip, then drag "Bloxstrap Mac" into your Applications folder.
2. First time only: right-click (or Control-click) the app, choose Open,
   then click Open again. (macOS asks because the app is not from the App Store.)
   If it says the app is damaged, open Terminal and run:
   xattr -cr "/Applications/Bloxstrap Mac.app"
3. Install Roblox from roblox.com if you haven't already.
4. Open Bloxstrap Mac, pick a preset (Max FPS, Balanced, Quality) or set an FPS cap,
   then choose Launch Roblox.

Custom fast flags: choose "Custom flags: add..." and enter a flag name and value.
"view or remove" lists them, "clear all" removes them. Custom flags override presets
with the same name. Roblox only honours some flags and silently ignores the rest.

If a dialog says it could not write the settings file: System Settings >
Privacy & Security > App Management (or Full Disk Access), allow Bloxstrap Mac.

Notes: Roblox may ignore some settings, and it overwrites them when it updates.
Launching through this app re-applies them every time.
